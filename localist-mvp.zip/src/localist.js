import React, { useState } from "react";

export default function LocalistMVP() {
  const [shop, setShop] = useState("");
  const [list, setList] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [status, setStatus] = useState("Pending");

  const shops = ["Tyagi Kirana Store", "Ravi Medicals", "Ankit Hardware"];

  const handleSubmit = (e) => {
    e.preventDefault();
    if (shop && list) {
      setSubmitted(true);
      setStatus("Pending");
    }
  };

  const shopActions = () => {
    setStatus("Preparing");
    setTimeout(() => setStatus("Ready for Pickup"), 2000);
  };

  return (
    <div style={{ padding: 20, maxWidth: 600, margin: "auto", background: "#fff", borderRadius: 12, boxShadow: "0 0 10px #ccc" }}>
      <h1 style={{ textAlign: "center" }}>📦 LocaList MVP</h1>

      {!submitted ? (
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: 12 }}>
            <label>Select Shop:</label><br />
            <select value={shop} onChange={(e) => setShop(e.target.value)} style={{ width: "100%", padding: 8 }}>
              <option value="">-- Choose --</option>
              {shops.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
          <div style={{ marginBottom: 12 }}>
            <label>Your Item List:</label><br />
            <textarea rows={4} style={{ width: "100%", padding: 8 }} placeholder="e.g., 1kg rice, 2L milk..." value={list} onChange={(e) => setList(e.target.value)}></textarea>
          </div>
          <button type="submit" style={{ width: "100%", padding: 10, background: "green", color: "#fff", border: "none", borderRadius: 8 }}>Send to Shop</button>
        </form>
      ) : (
        <div style={{ textAlign: "center" }}>
          <h2>Order Sent to {shop}!</h2>
          <p>Status: <strong>{status}</strong></p>
          <button onClick={shopActions} style={{ marginRight: 10, padding: 8, background: "blue", color: "#fff", border: "none", borderRadius: 8 }}>Simulate Shop Update</button>
          <button onClick={() => { setSubmitted(false); setShop(""); setList(""); setStatus("Pending"); }} style={{ padding: 8, background: "gray", color: "#fff", border: "none", borderRadius: 8 }}>New Order</button>
        </div>
      )}
    </div>
  );
}